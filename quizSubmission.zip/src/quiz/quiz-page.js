import Game from "./game";

function QuizPage() {
  return (
    <main>
      <Game></Game>
    </main>
  );
}

export default QuizPage;
